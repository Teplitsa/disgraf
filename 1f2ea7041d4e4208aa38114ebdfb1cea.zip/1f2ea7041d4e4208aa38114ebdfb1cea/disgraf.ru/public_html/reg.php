<?
include "system/connect.php";
include "system/functions.php";
/*определение функций*/////////////////////////////////////////////////////////////////////////////////////
function check_on_access()
{
	if (isset($_REQUEST[session_name()]))
	{
		session_start();
		$sesion = bd_ask('SELECT * FROM `session` where user = '.$_SESSION['id'],'');
		if ((time()-$sesion['session_time'])<(60*CONST_TIME) && $sesion['session_key'] == $_SESSION['key'])
		{
			header('Location: /cabinet/index.php');
		}
		else 
		{
		    $access = new access();    
		    $access->sesion_destroy();
		}
	}
}

function make_error()
{
    
}

function check_on_get_in()
{
	if ($_POST['first_name'] && $_POST['last_name'] && $_POST['phone'] && $_POST['password'])
	{
		$user_id_old = bd_ask('SELECT * FROM `user` where phone = '.$_POST['phone'],'id');
		if (!$user_id_old)
		{
		    $_POST['phone'] = str_replace("+7", "", $_POST['phone']);
	        $_POST['phone'] = preg_replace('~\D+~','',$_POST['phone']); 
			$user_id = bd_ins('INSERT INTO `user` (`first_name`, `last_name`, `phone`, `password`) VALUES ( "'.$_POST['first_name'].'", "'.$_POST['last_name'].'","'.$_POST['phone'].'","'.$_POST['password'].'")');
			$user = bd_ask('SELECT * FROM `user` where id = '.$user_id,'');
			$access = new access();
            $access->sesion_start($user);
			header('Location: /cabinet/index.php');
		} else
		{
		    make_error();
		}
	}
}

/*тело*///////////////////////////////////////////////////////////////////////////////////////////////////
check_on_access(); 
check_on_get_in();
?>   

<!DOCTYPE html>
<head>
  <meta charset="utf-8">
  <title>Дисграф - Регистрация</title>
  <meta content="width=device-width, initial-scale=1" name="viewport">
  <meta content="Webflow" name="generator">
  <link href="css/normalize.css" rel="stylesheet" type="text/css">
  <link href="css/webflow.css" rel="stylesheet" type="text/css">
  <link href="css/reg.css" rel="stylesheet" type="text/css">
  <link href="css/header.css" rel="stylesheet" type="text/css">
  <script src="js/modernizr.js" type="text/javascript"></script>
</head>
<body>
<header>
      <div class="wrapper">
        <nav>
          <ul>
            <li> <a href="/landing.php#service">о сервисе</a></li>
            <li> <a href="/landing.php#about_us">о нас</a></li>
            <li> <a href="/landing.php#technique">методики</a></li>
            <li> <a href="/landing.php#partners">партнёрам</a></li>
            <li> <a href="/landing.php#contact">контакты</a></li>
          </ul>
        </nav>
        <button class="open_form">&emsp;&emsp;&emsp;&emsp;&emsp;</button>
      </div>
    </header>
  <div class="content w-clearfix">
    <div class="photo_block w-hidden-medium w-hidden-small w-hidden-tiny"></div>
    <div class="registration_block">
      <div class="registration_form w-container">
        <h1>Регистрация</h1>
        <div class="w-form">
          <form data-name="registration" id="wf-form-registration" method="post" name="wf-form-registration">
            <label for="first_name">Имя:</label>
            <input class="w-input" data-name="first_name" id="first_name" maxlength="256" name="first_name" placeholder="Иван" required="required" type="text">
            <label for="last_name">Фамилия:</label>
            <input class="w-input" data-name="last_name" id="last_name" maxlength="256" name="last_name" placeholder="Иванов" required="required" type="text">
            <label for="phone">Телефон:</label>
            <input class="w-input" data-name="phone" id="phone" maxlength="256" name="phone" placeholder="9231701075" required="required" type="text">
            <label for="password">Пароль:</label>
            <input class="w-input" data-name="password" id="password" maxlength="256" name="password" placeholder="*************" required="required" type="password">
            <input class="submit-button w-button" type="submit" value="Зарегистрироваться">
          </form>
          <div class="success-message w-form-done"></div>
          <div class="w-form-fail">
            <div>Что-то введено не правильно</div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js" type="text/javascript"></script>
  <script src="js/webflow.js" type="text/javascript"></script>
  <script type="text/javascript">(window.Image ? (new Image()) : document.createElement('img')).src = 'https://vk.com/rtrg?p=VK-RTRG-119678-eW60o';</script>
  <!-- [if lte IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/placeholders/3.0.2/placeholders.min.js"></script><![endif] -->
</body></html>