<!DOCTYPE html>
<!--  This site was created in Webflow. http://www.webflow.com -->
<!--  Last Published: Wed May 10 2017 21:51:12 GMT+0000 (UTC)  -->
<html data-wf-page="5913897d0abf7b7895b5c17e" data-wf-site="5913897d0abf7b7895b5c17d">
<head>
  <meta charset="utf-8">
  <title>Тест на дисграфию</title>
  <meta content="Пройди тест на дисграфию онлайн" name="description">
  <meta content="width=device-width, initial-scale=1" name="viewport">
  <meta content="Webflow" name="generator">
  <link href="css/normalize.css" rel="stylesheet" type="text/css">
  <link href="css/webflow.css" rel="stylesheet" type="text/css">
  <link href="css/disgraf-test.webflow.css" rel="stylesheet" type="text/css">
  <link href="css/lk_main.css" rel="stylesheet" type="text/css">
</head>
<body class="body">
  <div class="container w-container">
  <div class="div-block">
  <h1 class="heading">Тестирование</h1>
  <h3 id="for_header" class="heading-2"></h3>
  </div>
  <div class="full_test">
  <div class="test" id="for_test" data-ix="on-next">
  <p>По результатам тестирования мы выясним определяющий вид дисграфии и дадим дальнейшие рекомендации!</p>
  <a class="submit-button w-button button" style="float:none;" onClick='$.post("../system/ask.php",{req:"test_send",block:1},new_test_response); block_1--;'>Пройти тест</a>
  </div>
  </div>
  </div>
  <div class="pluso" data-background="transparent" data-options="big,square,line,horizontal,counter,theme=01" data-services="vkontakte,odnoklassniki,facebook,twitter" data-url="http://disgraf.ru" data-image="http://artemy.pro/img/logo_icon.png" data-title="Пройди тест на дисграфию" style="margin-top: 50px;" data-description="лплалала"></div>
  </div>
  </div>
  <div id="hiddent_b" style="visibility: hidden;">
      <br><br><a class="submit-button w-button button" style="float:none;" href="reg.php">Зарегистрироваться</a>
  </div>
</div>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js" type="text/javascript"></script>
  <script type="text/javascript">
  (function() {
  if (window.pluso)if (typeof window.pluso.start == "function") return;
  if (window.ifpluso==undefined) { window.ifpluso = 1;
    var d = document, s = d.createElement('script'), g = 'getElementsByTagName';
    s.type = 'text/javascript'; s.charset='UTF-8'; s.async = true;
    s.src = ('https:' == window.location.protocol ? 'https' : 'http')  + '://share.pluso.ru/pluso-like.js';
    var h=d[g]('body')[0];
    h.appendChild(s);
  }})();
  </script>
  <script src="js/test.js" type="text/javascript"></script>
  <script type="text/javascript">(window.Image ? (new Image()) : document.createElement('img')).src = 'https://vk.com/rtrg?p=VK-RTRG-119678-eW60o';</script>
  <!-- [if lte IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/placeholders/3.0.2/placeholders.min.js"></script><![endif] -->
</body>
</html>