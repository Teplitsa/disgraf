<?
header('Location: landing.php');
?>