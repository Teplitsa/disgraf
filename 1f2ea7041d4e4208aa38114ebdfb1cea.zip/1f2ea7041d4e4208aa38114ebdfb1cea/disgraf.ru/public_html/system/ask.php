<?
include "connect.php";
include "functions.php";
//////////////////FOR ASK_PAGES
//include "ask_pages/order.php";
//ACCESS SWITCH////////////////////////////////////////////////////
session_start();
//TEST SWITCH/////////////////////////////////////////////////////////////////////////////////////////////////
switch ($_REQUEST['req']) {
    case 'text_test_ans':
        text_test_ans(trim($_POST['id']),trim($_POST['ans']),trim($_POST['block']),trim($_POST['old_q']));
        break;
    case 'test_send':
        test_send(trim($_POST['block']));
        break;
    case 'result_send':
        result_send(trim($_POST['block1']),trim($_POST['block2']),trim($_POST['block3']));
        break;
    case 'ask_exit_panel':
        ask_exit_panel();
        break;
}

/*Functions*///////////////////////////////////////////////////////////////////////////////////////
/*Exit*///////////////////////////////////////////////////////////////////////////////////////
function ask_exit_panel()
{
    $access = new access();    
	$access->sesion_destroy();
	header('Location: /');
}

function result_send($block1,$block2,$block3)
{
    $res_count_count = bd_ask('SELECT COUNT(*) FROM `statistic` WHERE id_user='.$_SESSION['id'],'COUNT(*)')+1;
    if($res_count_count<3)
    {
        $block1=round($block1*100); $block2=round($block2*100); $block3=round($block3*100);
        $res = '|'.$block1.'|'.$block2.'|'.$block3.'|';
        bd_ins('INSERT INTO `statistic` (`id_user`, `number`, `result`) VALUES ( "'.$_SESSION['id'].'", "'.$res_count_count.'","'.$res.'")');
    }
}

function make_replace($text,$str,$replace)
{
    $i=0;
    while (strpos($text, $str) !==false)
    {
        $pos = strpos($text, $str);
        $replace_end = make_replace($replace,'~i',$i);
        $text = substr_replace($text, $replace_end, $pos, strlen($str));
        $i++;
    }
    $res = array($text, $i);
    return $res;
}



function test_send($block,$old_q)
{
    $test = bd_ask('SELECT * FROM `text_test` WHERE block='.$block.' ORDER BY RAND() LIMIT 1','');
    $str = '~field';
    $res = make_replace($test['test_text'],'~field','<input class="answer w-input" style="width: 274px;" maxlength="256" id="ans_~i" name="ans_~i" placeholder="" required="required" type="text">');
    if (strripos($old_q, '|'.$test['id'])===false) 
    {
        echo $test['header'].'|<div>'.$res[0].'<a class="submit-button w-button button" data-ix="on-next" onClick="count_text_points(\''.$test['id'].'\','.$res[1].');">Дальше</a></div>|'.$test['id'];
    } else
    {
        test_send($block,$old_q);
    }
}

function text_test_ans($id,$ans,$block,$old_q)
{
    $ans = str_replace("ё", "е", $ans);
    $count_wrong=0;
    $test = bd_ask('SELECT * FROM `text_test` where id = '.$id,'');
    $ans_pieces = explode("|", $ans);
    $ans_pieces_true = explode("|", $test['test_ans']);
    for ($i=1; $i<count($ans_pieces); $i++)
    {
        if ($ans_pieces[$i]!=$ans_pieces_true[$i]) $count_wrong++;
    }
    $points=0;
    if ($count_wrong<=$test['p1']) $points=1;
    if ($count_wrong<=$test['p2']) $points=2;
    if ($count_wrong<=$test['p3']) $points=3;
    if ($count_wrong<=$test['p4']) $points=4;
    echo $points.'|';
    
    if ($test['p4']!=-1) { $point_max = 4;}
    else if ($test['p3']!=-1) { $point_max = 3;}
    else if ($test['p2']!=-1) { $point_max = 2;}
    else if ($test['p1']!=-1) { $point_max = 1;}
    
    if ($block!=0) 
    {
        test_send($block,$old_q);
        echo '|'.$test['block'].'|'.$point_max;
    } else
    {
      echo '0';  
      echo '|||'.$test['block'].'|'.$point_max;
    }
}
?>