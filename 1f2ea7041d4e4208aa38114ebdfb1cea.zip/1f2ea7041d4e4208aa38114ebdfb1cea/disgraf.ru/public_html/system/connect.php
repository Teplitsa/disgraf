<?php
//define("PANEL_URL", "/client/");
$dblocation = "localhost";
$dbname = "vkarlms6_disgraf";
$dbuser = "vkarlms6_disgraf";
$dbpasswd = "089808art";
$dbcnx = @mysql_connect($dblocation,$dbuser,$dbpasswd);
// в какой кодировке получать данные от клиента
/*mysql_query("set character_set_client='cp1251'");
mysql_query("set character_set_results='cp1251'");
mysql_query("set collation_connection='cp1251_general_ci'");*/
if (!$dbcnx) 
{
  echo( "<P>¬ насто¤щий момент сервер базы данных не доступен, поэтому 
            корректное отображение страницы невозможно.</P>" );
  exit();
}
else 
{

}
if (!@mysql_select_db($dbname, $dbcnx)) 
{
  echo( "<P>¬ насто¤щий момент база данных не доступна, поэтому
            корректное отображение страницы невозможно.</P>" );
  exit();
}

?>