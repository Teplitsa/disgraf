<?
header('Location: make_test.php');
?>