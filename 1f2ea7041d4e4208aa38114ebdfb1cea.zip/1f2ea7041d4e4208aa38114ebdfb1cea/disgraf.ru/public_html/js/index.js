// Появление изображения в блоке 'партнёры'
$('.content_bottom_element button').mouseenter(function() {
    $(this).parents('.content_bottom_info_block').children('.mask_background').css({
      opacity: .5
    })
})

$('.content_bottom_element button').mouseleave(function() {
    $(this).parents('.content_bottom_info_block').children('.mask_background').css({
      opacity: 0
    })
})

//Появление popup
$('.more').click( function() {
  $('body').addClass('active');
  $(this).parent('div').siblings('.content_info_popup').css({'display': 'flex', 'opacity': 0});
    $(this).parent('div').siblings('.content_info_popup').animate({opacity: 1}, 500 , function(){
      $(this).children('.popup_block').css({'display': 'block', 'opacity': 0});
      $(this).children('.popup_block').animate({opacity: 1, margin: '0'}, 500 );
    });
});

$('.close_popup').click( function() {
  $('body').removeClass('active');

  $(this).parents('.content_info_popup').animate({opacity: 0}, 500 , function(){
      $(this).css({'display': 'none'});
      $(this).children('.popup_block').css({opacity: 0, margin: '-200px 0 0'})
    });

  $(this).parents('.sing-in').animate({opacity: 0}, 500 , function(){
      $(this).css({'display': 'none'});
      $(this).children('.sing-in_block').css({opacity: 0, margin: '-200px 0 0'})
    });
});

//Появление формы
$('.open_form').click( function() {
  $('body').addClass('active');
  $(this).parents('body').find('.sing-in').css({'display': 'flex', 'opacity': 0});
    $(this).parents('body').find('.sing-in').animate({opacity: 1}, 500 , function(){
      $(this).children('.sing-in_block').css({'opacity': 0});
      $(this).children('.sing-in_block').animate({opacity: 1, margin: '0'}, 500 );
    });
});


//Передвижение ползунка
$('.content_individual_age').mouseenter(function() {
  if($(this).index() == 1) {
    $(this).siblings('.content_individual_tital').find('.individual_line-move').css({
      left: '18%',
      width: '106px'
    });
  } else if($(this).index() == 2) {
    $(this).siblings('.content_individual_tital').find('.individual_line-move').css({
      left: '82%',
      width: '106px'
    });
  }
});

$('.content_individual_age').mouseleave(function() {
  $(this).siblings('.content_individual_tital').find('.individual_line-move').css({
      left: '50%',
      width: '75px'
    });
})



//Якоря
    $(document).on("scroll", onScroll);
    $('header li a[href^="#"], .arrow_down a[href^="#"]').on('click', function (e) {
        e.preventDefault();
        $(document).off("scroll");
        
        $('header li a').removeClass('active');
        $(this).addClass('active');
      
        var target = this.hash,
            menu = target;
        $target = $(target);
        $('html, body').stop().animate({
            'scrollTop': $target.offset().top-50
        }, 500, 'swing', function () {
            window.location.hash = target;
            $(document).on("scroll", onScroll);
        });
    });
function onScroll(event){
    var scrollPos = $(document).scrollTop();
    $('header li a').each(function () {
        var currLink = $(this);
        var refElement = $(currLink.attr("href"));
        if (refElement.position().top <= scrollPos+50 && refElement.position().top + refElement.height() > scrollPos+50) {
            $('.header li a').removeClass("active");
            currLink.addClass("active");
        }
        else{
            currLink.removeClass("active");
        }
    });
}


//Анимация полей в форме
$(function() {
  $('input').each(function() {
    $(this).on('keyup', function() {

      var $el = $(this),
        length = $el.val().length;

        if(length > 0) {
          $el.addClass('dirty')
        } else {
          $el.removeClass('dirty')
        }
    });
  });

});

$('#phone').on('click', function () {
  $(this).inputmask({mask: "99-99999999"})
})


/*$('.profile_panel_options li a').on('click', function() {
  $('.profile_panel_options li a').removeClass('active');
  $(this).addClass('active');
});*/

